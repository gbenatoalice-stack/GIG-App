import React from 'react';
import { View, Text } from 'react-native';
export default function AppNavigator(){return(<View><Text>Navigation</Text></View>);}